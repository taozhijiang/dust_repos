# jd_spider

用来爬虫抓取某东的产品用户资讯和回答的程序。

在目录下使用python run.py即可

依赖于sqlite3和BeautifulSoup，以及urllib2
